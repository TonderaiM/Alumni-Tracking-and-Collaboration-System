from django.conf.urls import url
from django.contrib import admin
from . import views

app_name = "alumni"

urlpatterns =[
    url(r'^$', views.login_view, name='login_view'),
    url(r'^index/$', views.index, name='index'),
    url(r'^register/$',views.UserFormView.as_view(), name='register'),
    url(r'^edit_profile/$',views.edit_profile, name ='edit_profile'),
    url(r'^logout/$', views.logout_user, name='logout'),

    # url(r'^index/createprofile/$', views.ProfileCreate.as_view(), name='create_profile'),
    url(r'^profile/createprofile/$', views.CreateProfile.as_view(), name='create_profile'),
    url(r'^profile/editprofile/$', views.EditProfile.as_view(), name='edit_profile'),
    url(r'^profile/createeducation/$', views.CreateEducation.as_view(), name='create_education'),

    url(r'^index/companycreate/$', views.CompaniesCreate.as_view(), name='company_create'),
    url(r'^announcements/$', views.announcements, name='announcements'),
    url(r'^create_announcement/$', views.AnnouncementCreate.as_view(), name='announce'),
    # url(r'^index/profile/$',views.ProfileFormView.as_view(), name ='profile'),
    #url(r'^index/employement/$', views.EmployementFormView().as_view(), name =
    url(r'^people/$', views.people, name='people'),
    url(r'^add_employment/$', views.EmploymentCreate.as_view(), name='create_employment'),

    # Events
    url(r'^events/$', views.events, name='events'),
    url(r'^employement$', views.employement, name='employement'),

    # Bulletin
    url(r'^bulletin/$', views.bulletin, name='bulletin'),
    url(r'^bulletin/story/(?P<pk>[0-9]+)/$', views.bulletin_details, name='bulletin_details'),
    url(r'^bulletin/add/$', views.add_bulletin, name='bulletin_add'),

    # Calendar
    url(r'^calendar/$', views.calendar, name='calendar'),

    url(r'^create_post/$', views.create_post, name='create_post'),
    url(r'^post/(?P<pk>[0-9]+)/$', views.fullPostView, name='full_post'),
    url(r'^post/comment/$', views.CommentPost.as_view(), name='comment'),

    # Contact us
    url(r'^contact_us/$', views.contact_us, name='contact_us'),
    url(r'^contact_thanks/$', views.contact_thanks, name='contact_thanks'),
    url(r'^questions/$', views.contact_us_questions, name='contact_us_questions'),
    url(r'^reply/(?P<pk>[0-9]+)/$', views.reply_page, name='reply'),
    url(r'^question/reply/$', views.ReplyUser.as_view(), name='reply_user'),

    # Contacts
    url(r'^contacts/add/(?P<username>.*)/$', views.add_contact, name='add_contact'),

    # Settings
    url(r'^settings/$', views.settings, name='settings'),

    # Messages
    url(r'^messages/$', views.messages, name='messages'),
    url(r'^message/(?P<pk>[0-9]+)/$', views.conversationView, name='conversation'),
    url(r'^message/compose/$', views.composeMessage, name='compose_message'),
    url(r'^chat/$', views.chat, name='chat'),
    url(r'^new_messages/$', views.get_new_messages, name='new_messages'),

    # Help
    url(r'^help/$', views.help, name='help'),
    url(r'^help_details/(?P<pk>[0-9]+)/$', views.help_details, name='help_details'),

    url(r'^search/$', views.search, name= 'search'),

    url(r'^about/$', views.about, name='about'),

    url(r'^employment/$', views.employement, name='employment'),
    url(r'^education/$', views.education, name='education'),
    url(r'^websites/$', views.websites, name='websites'),

    url(r'^advertisements/$', views.advertisements, name='advertisements'),
    url(r'^advertisements/(?P<pk>[0-9]+)/$', views.advertisementsView, name='advertisements_detail'),
    url(r'^batchmates/$', views.batchmates, name='batchmates'),
    url(r'^person/(?P<pk>[0-9]+)/$', views.personView, name='person_view'),
    url(r'^update_profile/(?P<pk>[0-9]+)/$', views.ProfileUpdate.as_view() , name='update_profile'),



]

