import os
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.views.generic import View
from .forms import UserForm, CreateAnnouncementForm, EmployementForm, ReplyForm, CreateProfileForm, CreateEducationForm
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import Companies, Employement, Announcement, Notification, About, Profile
from .models import *;
from django.shortcuts import HttpResponseRedirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
import base64
from random import uniform
from django.utils import timezone
from .forms import *
from django.contrib.auth.models import User
from django.shortcuts import render, get_object_or_404
from django.views.generic.detail import DetailView
from .models import *
from django.views.generic.edit import UpdateView
from alumni.models import Profile

from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.shortcuts import get_object_or_404, redirect, render
from PIL import Image

AUDIO_FILE_TYPES = ['wav', 'mp3', 'ogg']
IMAGE_FILE_TYPES = ['png', 'jpg', 'jpeg']


# Create your views here.
class CompaniesCreate(CreateView):
    model = Companies
    fields = ['company_name', 'location_town', 'location_country', 'location_state', 'location_province',
              'industry', 'field', 'logo']


class EmploymentCreate(CreateView):
    model = Employment
    fields = ['position', 'company_name', 'job_details', 'field', 'start', 'end', 'current']


class UserCreate(CreateView):
    model = User
    fields = ['first_name', 'last_name', 'email', 'username', 'password']


# Show contacts
def people(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login')

    people_list = User.objects.all()

    paginator = Paginator(people_list, 20)
    page = request.GET.get('page')

    try:
        all_people = paginator.page(page)
    except PageNotAnInteger:
        all_people = paginator.page(1)
    except EmptyPage:
        all_people = paginator.page(paginator.num_pages)

    context = {'all_people': all_people}
    return render(request, 'alumni/people.html', context)


# Show announcements
def announcements(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login_view')
    #
    # noty = Notification.objects.get(user_name=request.user)
    # noty.announcement = 0
    # noty.save()

    announcement_list = Announcement.objects.all()

    paginator = Paginator(announcement_list, 20)
    page = request.GET.get('page')

    try:
        all_announcements = paginator.page(page)
    except PageNotAnInteger:
        all_announcements = paginator.page(1)
    except EmptyPage:
        all_announcements = paginator.page(paginator.num_pages)

    context = {'all_announcements': all_announcements}
    return render(request, 'alumni/announcements.html', context)


def notify(request, name):
    print(name)
    all_nots = Notification.objects.all()
    return redirect('admin')


class UserFormView(View):
    form_class = UserForm
    template_name = 'alumni/register.html'

    # display blank form
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # save data from form
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            user = form.save(commit=False)
            # cleaned data
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            username = form.cleaned_data['username']
            user.set_password(password)
            user.save()

            # returns user object if authenticated
            user = authenticate(email=username, password=password)

            if user is not None:
                if user.is_active:
                    login(request, user)
                    return render(request, 'alumni/index.html')
        context = {
            "form": form,
        }
        return render(request, 'alumni/register.html', context)


# login view

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                current_user = User.objects.get(username=username)
                try:
                    current_user.profile
                    return redirect('alumni:index')
                except Exception:
                    return redirect('alumni:create_profile')

            else:
                return render(request, 'alumni/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'alumni/login.html', {'error_message': 'Invalid login'})
    return render(request, 'alumni/login.html')


def about(request):
    about = About.objects.get(pk=1)
    return render(request, 'alumni/about.html', {"about": about})


# Show Events
def events(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login_view')

    # noty = Notification.objects.get(user_name=request.user)
    # noty.announcement = 0
    # noty.save()

    event_list = Event.objects.all()

    paginator = Paginator(event_list, 20)
    page = request.GET.get('page')

    try:
        all_events = paginator.page(page)
    except PageNotAnInteger:
        all_events = paginator.page(1)
    except EmptyPage:
        all_events = paginator.page(paginator.num_pages)

    context = {'all_events': all_events}
    return render(request, 'alumni/events.html', context)


# Bulletin
def bulletin(request):
    bulletin_list = Bulletin.objects.all()

    paginator = Paginator(bulletin_list, 20)
    page = request.GET.get('page')

    try:
        all_bulletin = paginator.page(page)
    except PageNotAnInteger:
        all_bulletin = paginator.page(1)
    except EmptyPage:
        all_bulletin = paginator.page(paginator.num_pages)

    context = {'all_bulletin': all_bulletin}

    return render(request, 'alumni/bulletin.html', context)


# Add Bulletin
def add_bulletin(request):
    if request.method == 'POST':
        bulletin = Bulletin();
        bulletin.writer = request.user
        bulletin.title = request.POST["title"]
        bulletin.story = request.POST["bulletin_story"]
        image_data = request.POST['bulletin_image'] + "========"
        image_data = image_data[image_data.find(",") + 1:]
        image_name = uniform(10000000, 90000000)
        image_name = str(image_name)
        image_name = image_name.replace(".", "")
        imgdata = base64.b64decode(image_data)
        filename = 'media/bulletin/' + image_name + '.jpg'
        with open(filename, 'wb') as f:
            f.write(imgdata)

        filename = filename.strip("media/")
        bulletin.image = filename
        bulletin.orientation = request.POST["orientation"]

        bulletin.save()
        if bulletin is not None:
            return HttpResponse("done" + str(bulletin.pk))

    return render(request, 'alumni/add_bulletin.html')


# Bulletin
def bulletin_details(request, pk):
    bulletin = Bulletin.objects.get(pk=pk)

    return render(request, 'alumni/bulletin_more.html', {"bulletin": bulletin})


# RSVP
def rsvp(request, event_id):
    event = Event.objects.get(id=event_id)
    check = RSVP.objects.filter(r_user=request.user, r_ann=event)
    if len(check) is 0:
        new_rsvp = RSVP(r_user=request.user, r_ann=event)
        new_rsvp.save()
    return HttpResponse(len(event.rsvp_set.all()))


# RSVP
def interested(request, int_id):
    event = Event.objects.get(id=int_id)
    check = Interest.objects.filter(i_user=request.user, i_ann=event)
    if len(check) is 0:
        new_int = Interest(i_user=request.user, i_ann=event)
        new_int.save()
    return HttpResponse(len(event.interest_set.all()))


# Login the user out
def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'alumni/login.html', context)


def index(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login_view')

    ann = Announcement.objects.all()[0]
    bulletin = Bulletin.objects.all()[0]
    posts_list = Post.objects.all()
    next_event = Event.objects.filter(event_date__gte=timezone.now()).order_by('event_date')
    event_not = None
    for event in next_event:
        event_not = event
        break

    paginator = Paginator(posts_list, 20)
    page = request.GET.get('page')

    try:
        all_posts = paginator.page(page)
    except PageNotAnInteger:
        all_posts = paginator.page(1)
    except EmptyPage:
        all_posts = paginator.page(paginator.num_pages)

    context = {'all_posts': all_posts, "announcement": ann, 'bulletin': bulletin, 'next_event': event_not}
    return render(request, 'alumni/index.html', context)


def edit_profile(request):
    pass


def register(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        first_name = form.cleaned_data['username']
        last_name = form.cleaned_data['password']
        email = form.cleaned_data['password']
        user.set_password(password)
        user.save()
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return render(request, 'alumni/index.html')
    context = {
        "form": form,
    }
    return render(request, 'alumni/register.html', context)


# Announcements
class AnnouncementCreate(View):
    form_class = CreateAnnouncementForm
    template_name = 'alumni/c_announcement.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            announcement_form = form.save(commit=False)

            subject = form.cleaned_data['subject']
            announcement = form.cleaned_data['announcement']
            external_link = form.cleaned_data['external_link']

            announcement_form.poster = request.user
            announcement_form.save()

            if announcement_form is not None:

                all_users = User.objects.all();

                for _user in all_users:
                    _user.notification.announcement += 1
                    noty = Notification.objects.get(user_name=_user)
                    noty.announcement += 1
                    noty.save()

                return redirect('alumni:announcements')

        return render(request, self.template_name, {'form': form})


def notify(request, name):
    print(name)
    all_nots = Notification.objects.all()
    return redirect('admin')


def calendar(request):
    if request.method == 'POST':
        new_event = Event();
        new_event.poster = request.user
        new_event.subject = request.POST["subject"]
        new_event.description = request.POST["description"]
        new_event.event_date = request.POST["event_date"]
        new_event.external_link = request.POST["external_link"]
        new_event.start_time = request.POST["start_time"]
        new_event.end_time = request.POST["end_time"]

        if request.POST["is_rsvp"] == "true":
            new_event.is_rsvp = True
        else:
            new_event.is_rsvp = False

        if request.POST["is_int"] == "true":
            new_event.is_interested = True
        else:
            new_event.is_interested = False

        # notification = Notification.objects.all()
        # for nots in notification:
        #     nots.events = nots.events + 1
        #     nots.save()
        #     print nots.events

        new_event.save()
        if new_event is not None:
            return HttpResponse("done")

    my_events = Event.objects.all()
    if not request.user.is_staff:
        return render(request, 'alumni/calendar/user_calendar.html', {"all_events": my_events})
    return render(request, 'alumni/calendar/calendar.html', {"all_events": my_events})


def contact_us(request):
    if request.method == 'POST':
        question = Question();
        question.contact = request.user
        question.subject = request.POST["subject"]
        question.message = request.POST["message"]
        question.status = True
        question.reply_id = 0

        question.save()
        if question is not None:
            return redirect("alumni:contact_thanks")
    return render(request, 'alumni/contact_us/contact.html')


def contact_thanks(request):
    return render(request, 'alumni/contact_us/thanks.html')


# Contact Reply
def contact_us_questions(request):
    if request.user.is_staff:
        question_list = Question.objects.all()
    else:
        question_list = Question.objects.filter(contact=request.user)

    paginator = Paginator(question_list, 20)
    page = request.GET.get('page')

    try:
        all_questions = paginator.page(page)
    except PageNotAnInteger:
        all_questions = paginator.page(1)
    except EmptyPage:
        all_questions = paginator.page(paginator.num_pages)

    context = {'all_questions': all_questions}

    return render(request, 'alumni/contact_us/reply.html', context)


# View full posts
def reply_page(request, pk):
    question = Question.objects.get(pk=pk)
    reply_list = question.questionreply_set.all()

    paginator = Paginator(reply_list, 5, 3)
    page = request.GET.get('page')

    try:
        replies = paginator.page(page)
    except PageNotAnInteger:
        replies = paginator.page(1)
    except EmptyPage:
        replies = paginator.page(paginator.num_pages)
    return render(request, 'alumni/contact_us/replies.html', {'question': question, 'replies': replies})


# Commenting Form
class ReplyUser(View):
    form_class = ReplyForm

    def get(self, request):
        form = self.form_class(request.GET)

        if form.is_valid():
            reply_form = form.save(commit=False)

            message = form.cleaned_data['message']
            question_id = request.GET['question_id']

            question = Question.objects.get(pk=question_id)

            reply_form.user_replying = request.user
            reply_form.question = question

            if request.user.is_staff:
                question.status = False
            else:
                question.status = True

            reply_form.save()
            return redirect('alumni:reply', question_id)
        return HttpResponse('Replied')


def add_contact(request, username):
    contact = User.objects.get(username=username)

    try:
        uc = UserContact.objects.get(user=request.user, contact=contact)
        return HttpResponse("already in contacts")
    except Exception as e:
        pass

    new_contact = UserContact()
    new_contact.user = request.user
    new_contact.contact = contact
    new_contact.save()

    if new_contact is not None:
        return HttpResponse("added")


def contacts(request):
    return render(request, 'alumni/contacts/contacts.html')


# Settings Page
def settings(request):
    if request.method == 'POST':
        user_name = request.user.username
        if request.user.check_password(request.POST["old"]):
            this_user = User.objects.get(username=request.user.username)
            this_user.set_password(request.POST["new_password"])
            this_user.save()
            user = authenticate(username=user_name, password=request.POST["new_password"])
            if user is not None:
                if user.is_active:
                    login(request, user)
            return HttpResponse("successful")
        else:
            return HttpResponse("failed")
    return render(request, 'alumni/settings.html')


# Messages

def messages(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login_view')

    message_list = Message.objects.filter(Q(sender=request.user) | Q(receiver=request.user))

    paginator = Paginator(message_list, 20)
    page = request.GET.get('page')

    try:
        all_messages = paginator.page(page)
    except PageNotAnInteger:
        all_messages = paginator.page(1)
    except EmptyPage:
        all_messages = paginator.page(paginator.num_pages)

    context = {'all_messages': all_messages}
    return render(request, 'alumni/messages.html', context)


# Conversation
def conversationView(request, pk):
    try:
        message = Message.objects.get(Q(pk=pk, sender=request.user) | Q(pk=pk, receiver=request.user))
        all_messages = Message.objects.filter(Q(sender=request.user) | Q(receiver=request.user))
    except Exception as e:
        pass

    new_messages = Conversation.objects.filter(message=message, read=False, receiver_c=request.user)

    for messag in new_messages:
        if messag.receiver_c == request.user:
            messag.read = True
            messag.save()

    # notification = Notification.objects.get(user_name=request.user)
    #
    # if notification.messages > 0:
    #     notification.messages = 0;
    #     notification.save()


    conv_list = message.conversation_set.all()

    paginator = Paginator(conv_list, 50, 3)
    page = request.GET.get('page')

    try:
        messages = paginator.page(page)
    except PageNotAnInteger:
        messages = paginator.page(1)
    except EmptyPage:
        messages = paginator.page(paginator.num_pages)
    return render(request, 'alumni/conversation.html',
                  {'message': message, 'messages': messages, 'all_messages': all_messages})


# Creating the Message
def composeMessage(request):
    if request.method == 'GET':
        try:
            to = User.objects.get(username=request.GET["to"])
        except Exception as e:
            to = ""
        try:
            fromhlf = request.GET["from"]
        except Exception as e:
            fromhlf = ""

        return render(request, 'alumni/compose_message.html', {"to": to, "from_h": fromhlf})
    if request.method == 'POST':
        rec = User.objects.get(username=request.POST["receiver"])
        sender = request.user
        try:
            conversation = Message.objects.get(Q(sender=sender, receiver=rec) | Q(sender=rec, receiver=request.user))
            return redirect('alumni:conversation', conversation.pk)
        except Exception as t:
            pass
        new_message = Message()
        new_message.sender = sender
        new_message.receiver = User.objects.get(username=request.POST["receiver"])
        new_message.subject = request.POST["subject"]
        new_message.message = request.POST["message"]

        new_message.save()

        # notification = Notification.objects.get(user_name=new_message.receiver)
        # notification.messages +=1;
        # notification.save()

        if new_message is not None:
            return redirect('alumni:messages')
    return render(request, 'alumni/compose_message.html')


def chat(request):
    if request.method == 'GET':
        new_chat = Conversation()
        new_chat.message = Message.objects.get(pk=request.GET["message_id"])
        new_chat.sender_c = request.user
        new_chat.receiver_c = User.objects.get(username=request.GET["receiver_c"])
        new_chat.message_body = request.GET["message_body"]
        new_chat.save()

        this_message = Message.objects.get(pk=request.GET["message_id"])
        this_message.message_to_display = request.GET["message_body"]
        this_message.save()

        # notification = Notification.objects.get(user_name=new_chat.receiver_c)
        # notification.messages +=1;
        # notification.save()

        if new_chat is not None:
            return HttpResponse("done")
        else:
            return HttpResponse("failed")
    return HttpResponse("none")


def get_new_messages(request):
    if request.method == 'GET':
        mssg = Message.objects.get(pk=request.GET["message_id"])
        new_messages = Conversation.objects.filter(message=mssg, read=False, receiver_c=request.user)

        for messag in new_messages:
            if messag.receiver_c == request.user:
                messag.read = True
                messag.save()

        # notification = Notification.objects.get(user_name=request.user)
        #
        # if notification.messages > 0:
        #     notification.messages = 0;
        #     notification.save()
        if len(new_messages) == 0:
            return HttpResponse("no messages")
        else:
            return render(request, 'alumni/cons.html', {"new_messages": new_messages})
    return HttpResponse("no new messages")


# End Of Messages

# Code for creating a Profile
class CreateProfile(View):
    form_class = CreateProfileForm
    template_name = 'alumni/create_profile.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name)

    def post(self, request):
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            profile = form.save(commit=False)

            user_picture = form.cleaned_data['user_picture']
            gender = form.cleaned_data['gender']
            date_of_birth = form.cleaned_data['date_of_birth']
            town_or_city = form.cleaned_data['town_or_city']
            cellphone_number = form.cleaned_data['cellphone_number']
            address = form.cleaned_data['address']
            country_of_residence = form.cleaned_data['country_of_residence']
            country_of_origin = form.cleaned_data['country_of_origin']

            mentor_or_mentee = form.cleaned_data['mentor_or_mentee']
            career_field_of_interest = form.cleaned_data['career_field_of_interest']
            field_of_study = form.cleaned_data['field_of_study']
            highest_qualification_aquired = form.cleaned_data['highest_qualification_aquired']
            institution = form.cleaned_data['institution']
            year_aquired = form.cleaned_data['year_aquired']
            interests = form.cleaned_data['interests']
            employement = form.cleaned_data['employement']
            education = form.cleaned_data['education']
            websites = form.cleaned_data['websites']
            networks = form.cleaned_data['networks']
            current_employment = form.cleaned_data['current_employment']
            current_education = form.cleaned_data['current_education']

            profile.user_name = request.user

            profile.save()

            if profile is not None:
                return HttpResponse("done")
        return HttpResponse("errors")


# Code for creating a Profile
class EditProfile(View):
    form_class = CreateProfileForm
    template_name = 'alumni/update_profile.html'

    def get(self, request):

        prof = Profile.objects.get(user_name=request.user)
        form_class = CreateProfileForm
        form = self.form_class(None)
        context = {"gender": prof.gender, "dob": prof.date_of_birth, "toc": prof.town_or_city,
                   "cell": prof.cellphone_number, "address": prof.address, "cor": prof.country_of_residence,
                   "coo": prof.country_of_origin, "mom": prof.mentor_or_mentee, "cfoi": prof.career_field_of_interest,
                   "fos": prof.field_of_study, "hqa": prof.highest_qualification_aquired, "inst": prof.institution,
                   "ya": prof.year_aquired, "interests": prof.interests,
                   "education": prof.education, "employement": prof.employement, "websites": prof.websites,
                   "networks": prof.networks,
                   "current_employment": prof.current_employment, "current_education": prof.current_education}
        return render(request, self.template_name, context)

    def post(self, request):
        this_user = Profile.objects.get(user_name=request.user)
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            profile = form.save(commit=False)

            user_picture = form.cleaned_data['user_picture']
            gender = form.cleaned_data['gender']
            date_of_birth = form.cleaned_data['date_of_birth']
            town_or_city = form.cleaned_data['town_or_city']
            cellphone_number = form.cleaned_data['cellphone_number']
            address = form.cleaned_data['address']
            country_of_residence = form.cleaned_data['country_of_residence']
            country_of_origin = form.cleaned_data['country_of_origin']

            mentor_or_mentee = form.cleaned_data['mentor_or_mentee']
            career_field_of_interest = form.cleaned_data['career_field_of_interest']
            field_of_study = form.cleaned_data['field_of_study']
            highest_qualification_aquired = form.cleaned_data['highest_qualification_aquired']
            institution = form.cleaned_data['institution']
            year_aquired = form.cleaned_data['year_aquired']
            interests = form.cleaned_data['interests']
            employement = form.cleaned_data['employement']
            education = form.cleaned_data['education']
            websites = form.cleaned_data['websites']
            networks = form.cleaned_data['networks']
            current_employment = form.cleaned_data['current_employment']
            current_education = form.cleaned_data['current_education']

            if user_picture is not None:
                this_user.user_picture = user_picture

            this_user.gender = gender

            this_user.date_of_birth = date_of_birth

            this_user.town_or_city = town_or_city
            this_user.cellphone_number = cellphone_number
            this_user.address = address

            if country_of_residence is not None:
                this_user.country_of_residence = country_of_residence
            if country_of_origin is not None:
                this_user.country_of_origin = country_of_origin
            if mentor_or_mentee is not None:
                this_user.mentor_or_mentee = mentor_or_mentee

            this_user.career_field_of_interest = career_field_of_interest
            this_user.field_of_study = field_of_study

            if highest_qualification_aquired is not None:
                this_user.highest_qualification_aquired = highest_qualification_aquired

            this_user.institution = institution
            this_user.year_aquired = year_aquired
            this_user.interests = interests
            this_user.employement = employement
            this_user.education = education
            this_user.websites = websites
            this_user.networks = networks
            this_user.current_employment = current_employment
            this_user.current_education = current_education

            this_user.save(force_update=True)

            if profile is not None:
                return HttpResponse("done")
        return HttpResponse("errors")


class CreateEducation(View):
    form_class = CreateEducationForm
    template_name = 'alumni/create_education.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name)

    def post(self, request):
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            education = form.save(commit=False)

            school_name = form.cleaned_data['school_name']
            level = form.cleaned_data['level']
            degree = form.cleaned_data['degree']
            program = form.cleaned_data['program']
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']

            education.user_name = request.user

            education.save()

            if education is not None:
                return HttpResponse("done")
        return HttpResponse("errors")


class EditProfile(View):
    form_class = CreateProfileForm
    template_name = 'alumni/update_profile.html'

    def get(self, request):

        prof = Profile.objects.get(user_name=request.user)
        form_class = CreateProfileForm
        form = self.form_class(None)
        context = {"gender": prof.gender, "dob": prof.date_of_birth, "toc": prof.town_or_city,
                   "cell": prof.cellphone_number, "address": prof.address, "cor": prof.country_of_residence,
                   "coo": prof.country_of_origin, "mom": prof.mentor_or_mentee, "cfoi": prof.career_field_of_interest,
                   "fos": prof.field_of_study, "hqa": prof.highest_qualification_aquired, "inst": prof.institution,
                   "ya": prof.year_aquired, "interests": prof.interests}
        return render(request, self.template_name, context)

    def post(self, request):
        this_user = Profile.objects.get(user_name=request.user)
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():

            profile = form.save(commit=False)

            user_picture = form.cleaned_data['user_picture']
            gender = form.cleaned_data['gender']
            date_of_birth = form.cleaned_data['date_of_birth']
            town_or_city = form.cleaned_data['town_or_city']
            cellphone_number = form.cleaned_data['cellphone_number']
            address = form.cleaned_data['address']
            country_of_residence = form.cleaned_data['country_of_residence']
            country_of_origin = form.cleaned_data['country_of_origin']

            mentor_or_mentee = form.cleaned_data['mentor_or_mentee']
            career_field_of_interest = form.cleaned_data['career_field_of_interest']
            field_of_study = form.cleaned_data['field_of_study']
            highest_qualification_aquired = form.cleaned_data['highest_qualification_aquired']
            institution = form.cleaned_data['institution']
            year_aquired = form.cleaned_data['year_aquired']
            interests = form.cleaned_data['interests']

            if user_picture is not None:
                this_user.user_picture = user_picture

            this_user.gender = gender

            this_user.date_of_birth = date_of_birth

            this_user.town_or_city = town_or_city
            this_user.cellphone_number = cellphone_number
            this_user.address = address

            if country_of_residence is not None:
                this_user.country_of_residence = country_of_residence
            if country_of_origin is not None:
                this_user.country_of_origin = country_of_origin
            if mentor_or_mentee is not None:
                this_user.mentor_or_mentee = mentor_or_mentee

            this_user.career_field_of_interest = career_field_of_interest
            this_user.field_of_study = field_of_study

            if highest_qualification_aquired is not None:
                this_user.highest_qualification_aquired = highest_qualification_aquired

            this_user.institution = institution
            this_user.year_aquired = year_aquired
            this_user.interests = interests

            this_user.save(force_update=True)

            if this_user is not None:
                return HttpResponse("done")
        return HttpResponse(form.errors)


def employement(request):
    if request.user.is_authenticated():
        if request.method == 'POST':
            form = EmploymentForm(request.POST)
            if form.is_valid():
                emp = form.save(commit=False)
                emp.user_name = request.user
                emp.save()
                return redirect('index.html')

        else:
            form = EmploymentForm()

            return render(request, 'alumni/my_template.html', {'form': form})
    else:
        return render(request, 'alumni/login.html')


# Create Timeline Post
def create_post(request):
    careers = Post.objects.all()

    if request.method == 'POST':

        post = Post()

        post.post = request.POST['post']

        post.poster = request.user

        post.save()

        if post is not None:
            return redirect('alumni:index')

    return render(request, 'alumni/timeline_post_box.html', {"all_careers": careers})


# View full posts
def fullPostView(request, pk):
    post = Post.objects.get(pk=pk)
    comment_list = post.comment_set.all()

    paginator = Paginator(comment_list, 5, 3)
    page = request.GET.get('page')

    try:
        comments = paginator.page(page)
    except PageNotAnInteger:
        comments = paginator.page(1)
    except EmptyPage:
        comments = paginator.page(paginator.num_pages)
    return render(request, 'alumni/full_post.html', {'post': post, 'comments': comments})


# Commenting Form
class CommentPost(View):
    form_class = CommentForm

    def get(self, request):
        form = self.form_class(request.GET)

        if form.is_valid():
            comment_form = form.save(commit=False)

            comment = form.cleaned_data['comment']
            post_id = request.GET['post_id']
            last_page = request.GET['last_page']

            post_to_comment = Post.objects.get(pk=post_id)

            comment_form.commenter = request.user
            comment_form.post = post_to_comment

            comment_form.save()
            return redirect('alumni:full_post', post_id)


# Help
def help(request):
    categories = HelpCategory.objects.all()

    context = {'categories': categories}

    return render(request, 'alumni/help/help.html', context)


def help_details(request, pk):
    topic = Help.objects.get(pk=pk)
    return render(request, 'alumni/help/details.html', {'topic': topic})


def about(request):
    about = About.objects.get(pk=1)
    return render(request, 'alumni/about.html', {"about": about})


def employement(request):
    prof = Profile.objects.get(user_name=request.user)
    return render(request, 'alumni/employment.html', {"prof": prof})


def education(request):
    prof = Profile.objects.get(user_name=request.user)
    return render(request, 'alumni/education.html', {"prof": prof})


def websites(request):
    prof = Profile.objects.get(user_name=request.user)
    return render(request, 'alumni/websites.html', {"prof": prof})


def advertisements(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login_view')

    adverts = Advertisements.objects.all()

    paginator = Paginator(adverts, 12)
    page = request.GET.get('page')

    try:
        all_adverts = paginator.page(page)
    except PageNotAnInteger:
        all_adverts = paginator.page(1)
    except EmptyPage:
        all_adverts = paginator.page(paginator.num_pages)

    context = {'all_adverts': all_adverts}
    return render(request, 'alumni/adverts.html', context)


def advertisementsView(request, pk):
    advert = Advertisements.objects.get(pk=pk)

    context = {"advert": advert}
    return render(request, 'alumni/advert_detail.html', context)


def batchmates(request):
    if not request.user.is_authenticated:
        return redirect('alumni:login')

    people_list = User.objects.all()

    paginator = Paginator(people_list, 20)
    page = request.GET.get('page')

    try:
        all_people = paginator.page(page)
    except PageNotAnInteger:
        all_people = paginator.page(1)
    except EmptyPage:
        all_people = paginator.page(paginator.num_pages)

    context = {'all_people': all_people}
    return render(request, 'alumni/batchmates.html', context)


def personView(request, pk):
    person = User.objects.get(pk=pk)

    context = {"person": person}
    return render(request, 'alumni/person_detail.html', context)


class ProfileUpdate(UpdateView):
    model = Profile
    fields = ['user_picture', 'gender', 'date_of_birth', 'town_or_city', 'cellphone_number', 'address',
              'country_of_residence',
              'country_of_origin', 'career_field_of_interest', 'field_of_study', 'highest_qualification_aquired',
              'institution',
              'year_aquired', 'interests', 'employement', 'education', 'websites', 'networks', 'current_employment',
              'current_education']
    template_name_suffix = '_update_form'


@login_required
def picture(request):
    uploaded_picture = False
    try:
        if request.GET.get('upload_picture') == 'uploaded':
            uploaded_picture = True

    except Exception:
        pass

    return render(request, 'alumni/picture.html',
                  {'uploaded_picture': uploaded_picture})
@login_required
def upload_picture(request):
    try:
        profile_pictures = django_settings.MEDIA_ROOT + '/profile_pictures/'
        if not os.path.exists(profile_pictures):
            os.makedirs(profile_pictures)
        f = request.FILES['picture']
        filename = profile_pictures + request.user.username + '_tmp.jpg'
        with open(filename, 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)
        im = Image.open(filename)
        width, height = im.size
        if width > 350:
            new_width = 350
            new_height = (height * 350) / width
            new_size = new_width, new_height
            im.thumbnail(new_size, Image.ANTIALIAS)
            im.save(filename)

        return redirect('/settings/picture/?upload_picture=uploaded')

    except Exception as e:
        print(e)
        return redirect('/settings/picture/')


@login_required
def save_uploaded_picture(request):
    try:
        x = int(request.POST.get('x'))
        y = int(request.POST.get('y'))
        w = int(request.POST.get('w'))
        h = int(request.POST.get('h'))
        tmp_filename = django_settings.MEDIA_ROOT + '/profile_pictures/' +\
            request.user.username + '_tmp.jpg'
        filename = django_settings.MEDIA_ROOT + '/profile_pictures/' +\
            request.user.username + '.jpg'
        im = Image.open(tmp_filename)
        cropped_im = im.crop((x, y, w+x, h+y))
        cropped_im.thumbnail((200, 200), Image.ANTIALIAS)
        cropped_im.save(filename)
        os.remove(tmp_filename)

    except Exception:
        pass

    return redirect('/settings/picture/')

@login_required
def search(request):
    if 'q' in request.GET:
        querystring = request.GET.get('q').strip()
        if len(querystring) == 0:
            return redirect('/search/')

        try:
            search_type = request.GET.get('type')
            if search_type not in ['feed', 'articles', 'questions', 'users']:
                search_type = 'feed'

        except Exception:
            search_type = 'feed'

        count = {}
        results = {}
        results['feed'] = Bulletin.objects.filter(post__icontains=querystring,
                                              parent=None)
        results['articles'] = Announcement.objects.filter(
            Q(title__icontains=querystring) | Q(content__icontains=querystring)
            )
        results['questions'] = Question.objects.filter(
            Q(title__icontains=querystring) | Q(
                description__icontains=querystring))
        results['users'] = User.objects.filter(
            Q(username__icontains=querystring) | Q(
                first_name__icontains=querystring) | Q(
                    last_name__icontains=querystring))
        count['feed'] = results['feed'].count()
        count['articles'] = results['articles'].count()
        count['questions'] = results['questions'].count()
        count['users'] = results['users'].count()

        return render(request, 'alumni/results.html', {
            'hide_search': True,
            'querystring': querystring,
            'active': search_type,
            'count': count,
            'results': results[search_type],
        })
    else:
        return render(request, 'search/search.html', {'hide_search': True})
