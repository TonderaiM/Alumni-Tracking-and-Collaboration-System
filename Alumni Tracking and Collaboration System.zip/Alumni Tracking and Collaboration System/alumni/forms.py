from django.contrib.auth.models import User
from django import forms
from .models import *
from django.forms import ModelForm


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['first_name','last_name','username', 'email', 'password']


class CreateProfileForm(forms.ModelForm):
	class Meta:
		model = Profile
		fields = ['user_picture', 'gender', 'date_of_birth', 'town_or_city', 'cellphone_number', 'address',
				  'country_of_residence', 'country_of_origin', 'mentor_or_mentee', 'career_field_of_interest',
				  'field_of_study', 'highest_qualification_aquired', 'institution', 'year_aquired', 'interests',
				  'education','employement','websites','networks','current_education','current_employment']

class CreateEducationForm(forms.ModelForm):
	class Meta:
		model = Education
		fields = ['school_name', 'level', 'degree', 'program','start_date', 'end_date']

class EmployementForm(forms.ModelForm):
	class Meta:
		model = Employement
		fields = ['position','job_details','field','start','end','current']
#Login Form
class Login(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
	email = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Email Address'}))

	class Meta:
		model = User
		fields = ['email', 'password']

class DateInput(forms.DateInput):
    input_type = 'date'

#Create Post Form
class CreatePostForm(forms.ModelForm):

	class Meta:
		model = Post
		fields = ['post']

#Comment Form
class CommentForm(forms.ModelForm):

	class Meta:
		model = Comment
		fields = ['comment']

#Announcements
class CreateAnnouncementForm(forms.ModelForm):

	class Meta:
		model = Announcement
		fields = ['subject', 'announcement', 'external_link']

#Reply Form
class ReplyForm(forms.ModelForm):

	class Meta:
		model = QuestionReply
		fields = ['message']

class EmploymentForm(ModelForm):
	class Meta:
		model = Employment
		fields = ['position','company_name','job_details','field','start','end','current']











