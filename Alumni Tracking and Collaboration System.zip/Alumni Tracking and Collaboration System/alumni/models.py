from django.db import models
#from imagekit.models import ProcessedImageField
# from imagekit.processors import ResizeToFill
# from imagekit.models import ImageSpecField
from django.contrib.auth.models import User,Group
from django.core.urlresolvers import reverse
from .validators import validate_video, validate_document
from .validators import validate_image



# Create your models here.
class Requests(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    is_accepted = models.BooleanField(default=False)

    def __str__(self):
        return self.student_no + ' ' + self.first_name + ' ' + "Accepted = " + self.is_accepted
class Bulletin(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=500)
    story = models.TextField()
    image = models.ImageField(upload_to='images/%Y/%m/%d/', validators=[validate_image])
    orientation = models.CharField(max_length=10)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.title)

class Companies(models.Model):
    company_name = models.CharField(max_length=200)
    location_town = models.CharField(max_length=200)
    location_country = models.CharField(max_length=200)
    location_state = models.CharField(max_length=200)
    location_province = models.CharField(max_length=200)
    industry = models.CharField(max_length=200)
    field = models.CharField(max_length=200)
    logo = models.FileField(max_length=500)

    def get_absolute_url(self):
        return reverse('alumni:index')

    def __str__(self):
        return self.company_name


class Employement(models.Model):
    user = models.OneToOneField(User, on_delete= models.CASCADE)
    position = models.CharField(max_length=200)
    job_details = models.TextField(max_length=1000)
    field = models.CharField(max_length=100)
    start = models.DateField(auto_now=False)
    end = models.DateField(auto_now=False)
    current = models.BooleanField(default=False)

    def __str__(self):
        return self.company_name + ' ' + self.position + ' ' + self.job_details + ' ' + self.field

class Employment(models.Model):
    user = models.OneToOneField(User, on_delete= models.CASCADE)
    position = models.CharField(max_length=200)
    company_name = models.CharField(max_length=250)
    job_details = models.TextField(max_length=1000)
    field = models.CharField(max_length=100)
    start = models.DateField(auto_now=False)
    end = models.DateField(auto_now=False)
    current = models.BooleanField(default=False)

    def __str__(self):
        return self.company_name + ' ' + self.position + ' ' + self.job_details + ' ' + self.field




class Career(models.Model):
    title = models.CharField(max_length=500)
    description = models.CharField(max_length=2500, null=True, blank=True)
    career_url = models.CharField(max_length=500)

    def __str__(self):
        return str(self.title)

    class Meta:
        ordering = ['title']

    # Profile Details
class Profile(models.Model):
    NA = ''
    MALE = 'MALE'
    FEMALE = 'FEMALE'
    GENDER_CHOICES = (
            (NA, 'N/A'),
            (MALE, 'MALE'),
            (FEMALE, 'FEMALE'),
        )

    user_name = models.OneToOneField(User, on_delete=models.CASCADE)
    user_picture = models.ImageField(upload_to='avatars', blank=True)
    gender = models.CharField(max_length=6, choices=GENDER_CHOICES, default=NA)
    date_of_birth = models.DateField(auto_now=False, auto_now_add=False)
    town_or_city = models.CharField(max_length=200)
    cellphone_number = models.CharField(max_length=15)
    address = models.CharField(max_length=500)
    country_of_residence = models.CharField(max_length=200)
    country_of_origin = models.CharField(max_length=200)

    mentor_or_mentee = models.CharField(max_length=2, blank=True)
    career_field_of_interest = models.CharField(max_length=200)
    field_of_study = models.CharField(max_length=200)
    highest_qualification_aquired = models.CharField(max_length=16, blank=True)
    institution = models.CharField(max_length=200)
    year_aquired = models.CharField(max_length=4, blank=True)
    interests = models.TextField(max_length=1000, blank=True)
    #Employemnt

    employement = models.TextField(max_length=2000,blank=True)
    education = models.TextField(max_length=2000, blank=True)
    websites = models.TextField(max_length=500,blank=True)
    networks = models.URLField(max_length=2000,blank=True)
    current_employment = models.TextField(max_length=2000,blank = True)
    current_education = models.TextField(max_length=2000,blank=True)

    def get_absolute_url(self):
        return reverse('alumni:index')

    def __str__(self):
        return str(self.user_name)

#Posts
class Post(models.Model):
    poster = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.TextField(max_length=1500)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.poster)+" "+ str(self.time)

#Comments to Posts
class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    commenter = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.CharField(max_length=1500)
    time_commented = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['time_commented']

    def __str__(self):
        return str(self.commenter)+" - "+ str(self.time_commented)


#Announcements
class Announcement(models.Model):
    poster = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.CharField(max_length=200)
    announcement =  models.TextField(max_length=2500)
    location = models.CharField(max_length=200, null=True, blank=True)
    posting_date = models.DateTimeField(auto_now=True)
    external_link = models.URLField(null=True, blank=True)

    class Meta:
        ordering  = ['-posting_date']

    def __str__(self):
        return str(self.poster)+" - "+ str(self.subject)


#Notifications
class Notification(models.Model):
    user_name = models.OneToOneField(User, on_delete=models.CASCADE)
    announcement = models.IntegerField(null=True, blank=True, default=0)
    messages = models.IntegerField(null=True, blank=True, default=0)
    events = models.IntegerField(null=True, blank=True, default=0)

    def __str__(self):
        return str(self.user_name)


class Message(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="messages", related_query_name="message")
    message_marker = models.TextField(max_length=500)
    subject = models.TextField(max_length=500, null=True, blank=True)
    message = models.TextField(max_length=2500)
    message_to_display = models.TextField(max_length=2500)
    read = models.BooleanField(default=False)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.sender) +" --> "+str(self.receiver)

class Conversation(models.Model):
    message = models.ForeignKey(Message, on_delete=models.CASCADE)
    sender_c = models.ForeignKey(User, on_delete=models.CASCADE)
    receiver_c = models.ForeignKey(User, on_delete=models.CASCADE, related_name="conversations", related_query_name="conversation")
    message_body = models.TextField(max_length=2500)
    read = models.BooleanField(default=False)
    time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.sender_c)+" -> "+str(self.receiver_c)



#Media

class Video(models.Model):
    uploader = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=500)
    circle = models.ForeignKey(Career, on_delete=models.CASCADE)
    description = models.CharField(max_length=2500, null=True, blank=True)
    thumbnail = models.ImageField(upload_to='video_thumbs',blank=True, null=True)
    video = models.FileField(upload_to='videos/%Y/%m/%d/', validators=[validate_video])
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.title)


class Picture(models.Model):
    uploader = models.ForeignKey(User, on_delete=models.CASCADE)
    circle = models.ForeignKey(Career, on_delete=models.CASCADE)
    title = models.CharField(max_length=500)
    description = models.CharField(max_length=2500, null=True, blank=True)
    image = models.ImageField(upload_to='images/%Y/%m/%d/', validators=[validate_image])
    image_thumbnail = models.ImageField(upload_to='thumbs',blank=True, null=True)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.title)


class Document(models.Model):
    uploader = models.ForeignKey(User, on_delete=models.CASCADE)
    circle = models.ForeignKey(Career, on_delete=models.CASCADE)
    title = models.CharField(max_length=500)
    description = models.CharField(max_length=2500, null=True, blank=True)
    document = models.ImageField(upload_to='documents/%Y/%m/%d/', validators=[validate_document])
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.title)


class About(models.Model):
    about = models.TextField()


class CareerFollower(models.Model):
    career = models.ForeignKey(Career, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.user)+" -> "+str(self.career)


#Event
class Event(models.Model):
    poster = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.CharField(max_length=200)
    description =  models.TextField(max_length=2500)
    event_date = models.DateField(auto_now=False, auto_now_add=False, null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    posting_date = models.DateTimeField(auto_now=True)
    is_rsvp = models.BooleanField()
    is_interested = models.BooleanField()
    start_time = models.CharField(max_length=50)
    end_time = models.CharField(max_length=50)
    external_link = models.URLField(null=True, blank=True)

    class Meta:
        ordering  = ['-posting_date']

    def __str__(self):
        return str(self.poster)+" - "+ str(self.subject)

#Is RVSP
class RSVP(models.Model):
    r_user = models.ForeignKey(User, on_delete=models.CASCADE)
    r_ann = models.ForeignKey(Event, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.r_user)

#Is Interested
class Interest(models.Model):
    i_user = models.ForeignKey(User, on_delete=models.CASCADE)
    i_ann = models.ForeignKey(Event, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.i_user)



class Bulletin(models.Model):
    writer = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=500)
    story = models.TextField()
    image = models.ImageField(upload_to='images/%Y/%m/%d/', validators=[validate_image])
    orientation = models.CharField(max_length=10)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.title)

class Question(models.Model):
    contact = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.CharField(max_length=500)
    message = models.CharField(max_length=2500)
    time = models.DateTimeField(auto_now=True)
    status = models.BooleanField()
    reply_id = models.IntegerField(null=True, blank=True, default=0)


    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.contact)

class QuestionReply(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    user_replying = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.CharField(max_length=2500)
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['time']

    def __str__(self):
        return str(self.user_replying)


class UserContact(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    contact = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contacts", related_query_name="contact")
    time = models.DateTimeField(auto_now=True)


    class Meta:
        ordering  = ['-time']

    def __str__(self):
        return str(self.user) + " -> "+str(self.contact)



#Help Models

class HelpCategory(models.Model):
    category = models.CharField(max_length=100)

    class Meta:
        ordering  = ['-category']

    def __str__(self):
        return self.category


#Help Title

class Help(models.Model):
    category = models.ForeignKey(HelpCategory, on_delete=models.CASCADE)
    topic = models.CharField(max_length=1000)
    time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.topic


class Step(models.Model):
    # topic = models.ForeignKey(Help, on_delete=models.CASCADE)
    step_number = models.IntegerField()
    description = models.TextField(max_length=1000)
    image = models.ImageField(upload_to='hep_images')
    time = models.DateTimeField(auto_now=True)

    class Meta:
        ordering  = ['step_number']

    def __str__(self):
        return str(self.topic)


class WebsitesAndNetworks(models.Model):
    user = models.ForeignKey(User, on_delete= models.CASCADE)
    website = models.CharField(max_length= 500)
    net_name = models.CharField(max_length=500)

    def __str__(self):
        return self.website+' '+ self.net_name


class Education(models.Model):
    user = models.OneToOneField(User, on_delete= models.CASCADE)
    school_name = models.CharField(max_length=250)
    level = models.CharField(max_length= 50)
    degree = models.CharField(max_length=50)
    program = models.CharField(max_length=100)
    start_date = models.DateField(auto_now=False, auto_now_add=False, null=True, blank=True)
    end_date = models.DateField(auto_now=False, auto_now_add=False, null=True, blank=True)

    def __str__(self):
        return self.school_name +' '+ self.level+' '+ self.degree+ ' '+ str(self.start_date)+' to '+ str(self.end_date)

class About(models.Model):
    about = models.TextField(max_length=5000)

    def __str__(self):
        return self.about


#Help Models

class HelpCategory(models.Model):
	category = models.CharField(max_length=100)

	class Meta:
		ordering  = ['-category']

	def __str__(self):
		return self.category


#Help Title

class Help(models.Model):
	category = models.ForeignKey(HelpCategory, on_delete=models.CASCADE)
	topic = models.CharField(max_length=1000)
	time = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.topic

class Advertisements(models.Model):
    company = models.CharField(max_length=200)
    title = models.CharField(max_length = 200)
    details = models.TextField(max_length =  2000)
    requirements = models.TextField(max_length=500)
    link = models.URLField(max_length= 250, blank = True)
    country = models.CharField(max_length=250, blank=True)
    time = models.DateTimeField(auto_now=True,blank=True)

    def __str__(self):
        return self.title +'->'+ self.company


